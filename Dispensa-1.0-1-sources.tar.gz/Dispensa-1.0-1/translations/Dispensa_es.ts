<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="es_ES">
<context>
    <name>About</name>
    <message>
        <location filename="../Source/about.ui" line="66"/>
        <source>About</source>
        <translation>About</translation>
    </message>
    <message>
        <location filename="../Source/about.ui" line="149"/>
        <source>Dispensa</source>
        <translation>Despensa</translation>
    </message>
    <message>
        <location filename="../Source/about.ui" line="194"/>
        <source>Copyright 2026 - Walter Giri</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../Source/about.ui" line="207"/>
        <source>Versione   1.0.0</source>
        <translation>Versión     1.0.0</translation>
    </message>
    <message>
        <location filename="../Source/about.ui" line="229"/>
        <source>This program is distributed in the hope that it will be useful,

    but WITHOUT ANY WARRANTY; without even the implied warranty of
    
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    
    GNU General Public License for more details.

</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../Source/about.ui" line="250"/>
        <source>Chiudi</source>
        <translation>Cierre</translation>
    </message>
</context>
<context>
    <name>Controlli</name>
    <message>
        <location filename="../Source/controlli.cpp" line="31"/>
        <source>Categoria obbligatoria</source>
        <translation>Categoría obligatoria</translation>
    </message>
    <message>
        <location filename="../Source/controlli.cpp" line="45"/>
        <source>Prodotto obbligatorio</source>
        <translation>Producto requerido</translation>
    </message>
    <message>
        <location filename="../Source/controlli.cpp" line="59"/>
        <source>Inserire Quantità</source>
        <translation>Introduzca la cantidad</translation>
    </message>
    <message>
        <location filename="../Source/controlli.cpp" line="67"/>
        <source>Quantità non numerica</source>
        <translation>Cantidad no numérica</translation>
    </message>
    <message>
        <location filename="../Source/controlli.cpp" line="84"/>
        <source>Nessuna Movimentazione</source>
        <translation>Sin movimiento</translation>
    </message>
    <message>
        <location filename="../Source/controlli.cpp" line="91"/>
        <source>Possibile una sola Movimentazione</source>
        <translation>Solo es posible un movimiento</translation>
    </message>
    <message>
        <location filename="../Source/controlli.cpp" line="101"/>
        <source>Quantità prelevata non numerica</source>
        <translation>Cantidad retirada no numérica</translation>
    </message>
    <message>
        <location filename="../Source/controlli.cpp" line="112"/>
        <source>Quantità depositata non numerica</source>
        <translation>Cantidad depositada no numérica</translation>
    </message>
    <message>
        <location filename="../Source/controlli.cpp" line="129"/>
        <source>Quantità Prelevata maggiore di quantità dispensa</source>
        <translation>Cantidad retirada mayor que la cantidad de la despensa</translation>
    </message>
    <message>
        <location filename="../Source/controlli.cpp" line="143"/>
        <source>Nessuna Modifica</source>
        <translation>Sin cambios</translation>
    </message>
</context>
<context>
    <name>Gestione</name>
    <message>
        <location filename="../Source/gestione.ui" line="66"/>
        <source>Gestione</source>
        <translation>Gestión</translation>
    </message>
    <message>
        <location filename="../Source/gestione.ui" line="149"/>
        <source>Gestione Dispensa</source>
        <translation>Gestión Despensa</translation>
    </message>
    <message>
        <location filename="../Source/gestione.ui" line="181"/>
        <source>Seleziona Categoria : </source>
        <translation>Selection Categoria : </translation>
    </message>
    <message>
        <location filename="../Source/gestione.ui" line="204"/>
        <source>Invia</source>
        <translation>Envía</translation>
    </message>
    <message>
        <location filename="../Source/gestione.ui" line="259"/>
        <source>Gestisci</source>
        <translation>Gestisci</translation>
    </message>
    <message>
        <location filename="../Source/gestione.ui" line="272"/>
        <source>Annulla</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <location filename="../Source/gestione.cpp" line="46"/>
        <source>Categoria : </source>
        <translation>Categoria : </translation>
    </message>
    <message>
        <location filename="../Source/gestione.cpp" line="50"/>
        <source>Non sono presenti Prodotti nella Categoria selezionata</source>
        <translation>No hay productos en esta categoría</translation>
    </message>
    <message>
        <location filename="../Source/gestione.cpp" line="79"/>
        <source>Nessuna Selezione</source>
        <translation>Sin selección</translation>
    </message>
</context>
<context>
    <name>Initia</name>
    <message>
        <location filename="../Source/initia.ui" line="66"/>
        <source>Dialog</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../Source/initia.ui" line="149"/>
        <source>Inizializzazione</source>
        <translation>Inicialización</translation>
    </message>
    <message>
        <location filename="../Source/initia.ui" line="236"/>
        <source>Programma</source>
        <translation>Programa</translation>
    </message>
    <message>
        <location filename="../Source/initia.ui" line="297"/>
        <source>Inizia</source>
        <translation>Empieza</translation>
    </message>
    <message>
        <location filename="../Source/initia.ui" line="310"/>
        <source>Chiudi</source>
        <translation>Cierre</translation>
    </message>
    <message>
        <location filename="../Source/initia.cpp" line="81"/>
        <source>Successo</source>
        <translation>Éxito</translation>
    </message>
    <message>
        <location filename="../Source/initia.cpp" line="85"/>
        <source>Fallito</source>
        <translation>Suspendido</translation>
    </message>
</context>
<context>
    <name>ListaSpesa</name>
    <message>
        <location filename="../Source/listaspesa.ui" line="66"/>
        <source>ListaSpesa</source>
        <translation>Lista de la compra</translation>
    </message>
    <message>
        <location filename="../Source/listaspesa.ui" line="149"/>
        <source>Lista Spesa</source>
        <translation>Lista de la compra</translation>
    </message>
    <message>
        <location filename="../Source/listaspesa.ui" line="181"/>
        <source>Crea Lista della Spesa :</source>
        <translation>Crea una lista de la compra:</translation>
    </message>
    <message>
        <location filename="../Source/listaspesa.ui" line="194"/>
        <source>Invia</source>
        <translation>Envía</translation>
    </message>
    <message>
        <location filename="../Source/listaspesa.ui" line="223"/>
        <source>E&apos; possibile modificare la Lista aggiungendo i quantitativi</source>
        <translation>Es posible modificar la Lista sumando las cantidades</translation>
    </message>
    <message>
        <location filename="../Source/listaspesa.ui" line="249"/>
        <source>Stampa</source>
        <translation>Impresión</translation>
    </message>
    <message>
        <location filename="../Source/listaspesa.ui" line="262"/>
        <source>Chiudi</source>
        <translation>Cierre</translation>
    </message>
    <message>
        <location filename="../Source/listaspesa.cpp" line="52"/>
        <source>Non è stato possibile creare la Lista</source>
        <translation>La Lista no pudo ser creada</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../Source/mainwindow.ui" line="67"/>
        <source>Dispensa</source>
        <translation>Despensa</translation>
    </message>
    <message>
        <location filename="../Source/mainwindow.ui" line="151"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Dispensa&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Despensa&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../Source/mainwindow.ui" line="196"/>
        <source>Prodotti</source>
        <translation>Productos</translation>
    </message>
    <message>
        <location filename="../Source/mainwindow.ui" line="210"/>
        <source>Visualizza</source>
        <translation>Vista</translation>
    </message>
    <message>
        <location filename="../Source/mainwindow.ui" line="224"/>
        <source>Gestione</source>
        <translation>Gestión</translation>
    </message>
    <message>
        <location filename="../Source/mainwindow.ui" line="269"/>
        <source>&amp;File</source>
        <translation>&amp;File</translation>
    </message>
    <message>
        <location filename="../Source/mainwindow.ui" line="278"/>
        <source>&amp;ToolAvanzati</source>
        <translation>&amp;ToolAvanzado</translation>
    </message>
    <message>
        <location filename="../Source/mainwindow.ui" line="291"/>
        <source>&amp;Stato_Dispensa</source>
        <translation>&amp;Estado_Despensa</translation>
    </message>
    <message>
        <location filename="../Source/mainwindow.ui" line="296"/>
        <source>&amp;Esci</source>
        <translation>&amp;Salida</translation>
    </message>
    <message>
        <location filename="../Source/mainwindow.ui" line="301"/>
        <source>&amp;About</source>
        <translation>&amp;About</translation>
    </message>
    <message>
        <location filename="../Source/mainwindow.ui" line="306"/>
        <source>&amp;ListaSpesa</source>
        <translation>&amp;Lista_delaCompra</translation>
    </message>
    <message>
        <location filename="../Source/mainwindow.ui" line="311"/>
        <source>&amp;EliminaCategoria</source>
        <translation>&amp;EliminaCategoria</translation>
    </message>
    <message>
        <location filename="../Source/mainwindow.ui" line="316"/>
        <source>&amp;ModificaCategoria</source>
        <translation>&amp;EditarCategoría</translation>
    </message>
    <message>
        <location filename="../Source/mainwindow.ui" line="321"/>
        <source>&amp;EliminaProdotto</source>
        <translation>&amp;EliminaProducto</translation>
    </message>
    <message>
        <location filename="../Source/mainwindow.ui" line="326"/>
        <source>&amp;ModificaProdotto</source>
        <translation>&amp;EditarProducto</translation>
    </message>
    <message>
        <location filename="../Source/mainwindow.cpp" line="77"/>
        <source>Elimina Categoria</source>
        <translation>Eliminar categoría</translation>
    </message>
    <message>
        <location filename="../Source/mainwindow.cpp" line="142"/>
        <source>Modifica Categoria</source>
        <translation>Editar categoría</translation>
    </message>
    <message>
        <location filename="../Source/mainwindow.cpp" line="152"/>
        <source>Elimina Prodotto</source>
        <translation>Eliminar producto</translation>
    </message>
    <message>
        <location filename="../Source/mainwindow.cpp" line="162"/>
        <source>Modifica Prodotto</source>
        <translation>Editar producto</translation>
    </message>
</context>
<context>
    <name>Movimenta</name>
    <message>
        <location filename="../Source/movimenta.ui" line="66"/>
        <source>Movimenta</source>
        <translation>Manejo</translation>
    </message>
    <message>
        <location filename="../Source/movimenta.ui" line="149"/>
        <source>Movimentazione Dispensa</source>
        <translation>Manejo de la despensa</translation>
    </message>
    <message>
        <location filename="../Source/movimenta.ui" line="188"/>
        <source>Seleziona Categoria : </source>
        <translation>Selection Categoria : </translation>
    </message>
    <message>
        <location filename="../Source/movimenta.ui" line="204"/>
        <source>Preleva</source>
        <translation>Retirada</translation>
    </message>
    <message>
        <location filename="../Source/movimenta.ui" line="220"/>
        <source>Deposita</source>
        <translation>Deposita</translation>
    </message>
    <message>
        <location filename="../Source/movimenta.ui" line="272"/>
        <source>Invia</source>
        <translation>Envía</translation>
    </message>
    <message>
        <location filename="../Source/movimenta.ui" line="285"/>
        <source>Annulla</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <location filename="../Source/movimenta.ui" line="298"/>
        <location filename="../Source/movimenta.ui" line="311"/>
        <source>TextLabel</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../Source/movimenta.cpp" line="76"/>
        <source>Movimentazione Dispensa avvenuta con Successo</source>
        <translation>Manejo exitoso de la despensa</translation>
    </message>
    <message>
        <location filename="../Source/movimenta.cpp" line="80"/>
        <source>Movimentazione Dispensa Fallita</source>
        <translation>Fallido en la gestión de la despensa</translation>
    </message>
    <message>
        <location filename="../Source/movimenta.cpp" line="100"/>
        <source>  Quantità : </source>
        <translation>  Cantidad : </translation>
    </message>
</context>
<context>
    <name>Prodotti</name>
    <message>
        <location filename="../Source/prodotti.ui" line="66"/>
        <source>Prodotti</source>
        <translation>Productos</translation>
    </message>
    <message>
        <location filename="../Source/prodotti.ui" line="149"/>
        <source>Inserimento Prodotti</source>
        <translation>Inserción de productos</translation>
    </message>
    <message>
        <location filename="../Source/prodotti.ui" line="181"/>
        <source>Categoria</source>
        <translation>Categoria</translation>
    </message>
    <message>
        <location filename="../Source/prodotti.ui" line="194"/>
        <source>Prodotto</source>
        <translation>Producto</translation>
    </message>
    <message>
        <location filename="../Source/prodotti.ui" line="217"/>
        <source>Invia</source>
        <translation>Envía</translation>
    </message>
    <message>
        <location filename="../Source/prodotti.ui" line="230"/>
        <source>Annulla</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <location filename="../Source/prodotti.ui" line="253"/>
        <source>Quantità</source>
        <translation>Cantidad</translation>
    </message>
    <message>
        <location filename="../Source/prodotti.cpp" line="59"/>
        <source>Inserimento prodotto avvenuto con successo</source>
        <translation>Entrada de producto con éxito</translation>
    </message>
    <message>
        <location filename="../Source/prodotti.cpp" line="63"/>
        <source>Inserimento prodotto fallito</source>
        <translation>Entrada de producto fallida</translation>
    </message>
</context>
<context>
    <name>SituazDisp</name>
    <message>
        <location filename="../Source/situazdisp.ui" line="66"/>
        <source>Situazione</source>
        <translation>Situación</translation>
    </message>
    <message>
        <location filename="../Source/situazdisp.ui" line="149"/>
        <source>Situazione Dispensa</source>
        <translation>Situación Despensa</translation>
    </message>
    <message>
        <location filename="../Source/situazdisp.ui" line="301"/>
        <source>Chiudi</source>
        <translation>Cierre</translation>
    </message>
    <message>
        <location filename="../Source/situazdisp.cpp" line="49"/>
        <source>Non sono presenti prodotti in Dispensa</source>
        <translation>No hay productos en la despensa</translation>
    </message>
</context>
<context>
    <name>TestModel</name>
    <message>
        <location filename="../Source/situazdisp.cpp" line="118"/>
        <source>Categoria</source>
        <translation>Categoria</translation>
    </message>
    <message>
        <location filename="../Source/situazdisp.cpp" line="120"/>
        <source>Prodotto</source>
        <translation>Producto</translation>
    </message>
    <message>
        <location filename="../Source/situazdisp.cpp" line="122"/>
        <source>Quantità</source>
        <translation>Cantidad</translation>
    </message>
</context>
<context>
    <name>Tools</name>
    <message>
        <location filename="../Source/tools.ui" line="66"/>
        <source>Tools</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../Source/tools.ui" line="220"/>
        <source>Annulla</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <location filename="../Source/tools.cpp" line="44"/>
        <location filename="../Source/tools.cpp" line="52"/>
        <location filename="../Source/tools.cpp" line="111"/>
        <source>Elimina Categoria</source>
        <translation>Eliminar categoría</translation>
    </message>
    <message>
        <location filename="../Source/tools.cpp" line="44"/>
        <location filename="../Source/tools.cpp" line="54"/>
        <location filename="../Source/tools.cpp" line="119"/>
        <source>Modifica Categoria</source>
        <translation>Editar categoría</translation>
    </message>
    <message>
        <location filename="../Source/tools.cpp" line="45"/>
        <source>Seleziona Categoria</source>
        <translation>Seleccionar Categoria</translation>
    </message>
    <message>
        <location filename="../Source/tools.cpp" line="48"/>
        <location filename="../Source/tools.cpp" line="52"/>
        <location filename="../Source/tools.cpp" line="139"/>
        <source>Elimina Prodotto</source>
        <translation>Eliminar producto</translation>
    </message>
    <message>
        <location filename="../Source/tools.cpp" line="48"/>
        <location filename="../Source/tools.cpp" line="54"/>
        <location filename="../Source/tools.cpp" line="104"/>
        <location filename="../Source/tools.cpp" line="147"/>
        <source>Modifica Prodotto</source>
        <translation>Editar producto</translation>
    </message>
    <message>
        <location filename="../Source/tools.cpp" line="49"/>
        <source>Seleziona Prodotto</source>
        <translation>Seleccionar Producto</translation>
    </message>
    <message>
        <location filename="../Source/tools.cpp" line="53"/>
        <source>Elimina</source>
        <translation>Elimina</translation>
    </message>
    <message>
        <location filename="../Source/tools.cpp" line="55"/>
        <source>Modifica</source>
        <translation>Edición</translation>
    </message>
    <message>
        <location filename="../Source/tools.cpp" line="67"/>
        <source>Nessun risultato</source>
        <translation>Sin resultados</translation>
    </message>
    <message>
        <location filename="../Source/tools.cpp" line="94"/>
        <source>Nessuna Selezione</source>
        <translation>Sin selección</translation>
    </message>
    <message>
        <location filename="../Source/tools.cpp" line="114"/>
        <source>Eliminazione Categoria avvenuta con Successo</source>
        <translation>Eliminación por categoría con éxito</translation>
    </message>
    <message>
        <location filename="../Source/tools.cpp" line="116"/>
        <source>Eliminazione Categoria Fallita</source>
        <translation>Eliminación por categoría fallida</translation>
    </message>
    <message>
        <location filename="../Source/tools.cpp" line="134"/>
        <source>Modifica Categoria avvenuta con Successo</source>
        <translation>Cambio de categoría con éxito</translation>
    </message>
    <message>
        <location filename="../Source/tools.cpp" line="136"/>
        <source>Modifica Categoria Fallita</source>
        <translation>Cambio de categoría fallido</translation>
    </message>
    <message>
        <location filename="../Source/tools.cpp" line="142"/>
        <source>Eliminazione Prodotto avvenuta con Successo</source>
        <translation>Eliminación de productos con éxito</translation>
    </message>
    <message>
        <location filename="../Source/tools.cpp" line="144"/>
        <source>Eliminazione Prodotto Fallita</source>
        <translation>Eliminación del producto fallida</translation>
    </message>
    <message>
        <location filename="../Source/tools.cpp" line="162"/>
        <source>Modifica Prodotto avvenuta con Successo</source>
        <translation>Cambio de producto con éxito</translation>
    </message>
    <message>
        <location filename="../Source/tools.cpp" line="164"/>
        <source>Modifica Prodotto Fallita</source>
        <translation>Cambio de producto fallido</translation>
    </message>
</context>
<context>
    <name>ToolsMod</name>
    <message>
        <location filename="../Source/toolsmod.ui" line="66"/>
        <source>ToolsModifica</source>
        <translation>ToolsEdición</translation>
    </message>
    <message>
        <location filename="../Source/toolsmod.ui" line="181"/>
        <location filename="../Source/toolsmod.ui" line="246"/>
        <source>Visualizza :</source>
        <translation>Ver:</translation>
    </message>
    <message>
        <location filename="../Source/toolsmod.ui" line="220"/>
        <source>Invia</source>
        <translation>Envía</translation>
    </message>
    <message>
        <location filename="../Source/toolsmod.ui" line="233"/>
        <source>Annulla</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <location filename="../Source/toolsmod.cpp" line="39"/>
        <location filename="../Source/toolsmod.cpp" line="59"/>
        <source>Modifica Categoria</source>
        <translation>Editar categoría</translation>
    </message>
    <message>
        <location filename="../Source/toolsmod.cpp" line="40"/>
        <location filename="../Source/toolsmod.cpp" line="44"/>
        <source>Categoria : </source>
        <translation>Categoria : </translation>
    </message>
    <message>
        <location filename="../Source/toolsmod.cpp" line="40"/>
        <location filename="../Source/toolsmod.cpp" line="44"/>
        <location filename="../Source/toolsmod.cpp" line="45"/>
        <source> - Inserisci Modifica :</source>
        <translation> - Introduce Edit :</translation>
    </message>
    <message>
        <location filename="../Source/toolsmod.cpp" line="45"/>
        <source>Prodotto : </source>
        <translation>Producto : </translation>
    </message>
    <message>
        <location filename="../Source/toolsmod.cpp" line="55"/>
        <source>Modifica Prodotto</source>
        <translation>Editar producto</translation>
    </message>
</context>
<context>
    <name>VisualElenco</name>
    <message>
        <location filename="../Source/visualelenco.ui" line="66"/>
        <source>Elenco</source>
        <translation>Lista</translation>
    </message>
    <message>
        <location filename="../Source/visualelenco.ui" line="181"/>
        <source>Seleziona Categoria :</source>
        <translation>Seleccionar Categoria :</translation>
    </message>
    <message>
        <location filename="../Source/visualelenco.ui" line="204"/>
        <source>Invia</source>
        <translation>Envía</translation>
    </message>
    <message>
        <location filename="../Source/visualelenco.ui" line="259"/>
        <source>Chiudi</source>
        <translation>Cierre</translation>
    </message>
    <message>
        <location filename="../Source/visualelenco.cpp" line="41"/>
        <source>tutto</source>
        <translation>Todo</translation>
    </message>
    <message>
        <location filename="../Source/visualelenco.cpp" line="42"/>
        <source>Elenco Generale</source>
        <translation>Lista General</translation>
    </message>
    <message>
        <location filename="../Source/visualelenco.cpp" line="52"/>
        <source>Non sono presenti Prodotti</source>
        <translation>No hay productos</translation>
    </message>
    <message>
        <location filename="../Source/visualelenco.cpp" line="59"/>
        <source>Elenco Categoria</source>
        <translation>Lista Caregoria</translation>
    </message>
    <message>
        <location filename="../Source/visualelenco.cpp" line="85"/>
        <source>Categoria : </source>
        <translation>Categoria : </translation>
    </message>
    <message>
        <location filename="../Source/visualelenco.cpp" line="94"/>
        <source>Non sono presenti Prodotti in questa categoria</source>
        <translation>No hay productos en esta categoría</translation>
    </message>
</context>
<context>
    <name>Visualizza</name>
    <message>
        <location filename="../Source/visualizza.ui" line="66"/>
        <source>Visualizza</source>
        <translation>Vista</translation>
    </message>
    <message>
        <location filename="../Source/visualizza.ui" line="149"/>
        <source>Visualizza Dispensa</source>
        <translation>Vista Despensa</translation>
    </message>
    <message>
        <location filename="../Source/visualizza.ui" line="181"/>
        <source>Visualizza :</source>
        <translation>Ver:</translation>
    </message>
    <message>
        <location filename="../Source/visualizza.ui" line="200"/>
        <source>Tutto</source>
        <translation>Todo</translation>
    </message>
    <message>
        <location filename="../Source/visualizza.ui" line="210"/>
        <source>Categoria</source>
        <translation>Categoria</translation>
    </message>
    <message>
        <location filename="../Source/visualizza.ui" line="226"/>
        <source>Invia</source>
        <translation>Envía</translation>
    </message>
    <message>
        <location filename="../Source/visualizza.ui" line="255"/>
        <source>Annulla</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <location filename="../Source/visualizza.cpp" line="36"/>
        <source>tutto</source>
        <translation>Todo</translation>
    </message>
    <message>
        <location filename="../Source/visualizza.cpp" line="37"/>
        <source>cat</source>
        <translation>cat</translation>
    </message>
</context>
</TS>
